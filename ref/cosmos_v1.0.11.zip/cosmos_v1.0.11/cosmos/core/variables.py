searchCount = 42
showMessages = True
startupHotkey = True
searchMayaMenus = True
iconBackColor = (65, 117, 174)

