__author__ = "Martin Gunnarsson (cosmos@deerstranger.com)"
__version__ = "1.0.11"
from core.startup import *
