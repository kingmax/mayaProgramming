########## Information ########## 
Name: Cosmos
Version: 1.0.11

Author: 
Martin Gunnarsson

Contact:
cosmos@deerstranger.com

Version Support:
Maya 2014 - 2017

For more info and change-log, visit:
http://cosmos.toolsfrom.space
http://cosmos.toolsfrom.space/documentation


##########  About ########## 
Cosmos is a launcher that helps you to do things faster in Maya.
Includes a bunch of build-in scripts that makes you do less boring stuff, and options to add your own custom scripts. Access all of Maya's own tools with ease.



##########  Installation ########## 
--- The steps are also laid out on the website: ---
http://cosmos.toolsfrom.space/documentation/docs/quick-start/installation/

1. Place the "cosmos" folder in maya's script directory. Normally here:
	Windows:  C:\Users\USERNAME\Documents\maya\scripts\	
	Mac:      /Users/USERNAME/Library/Preferences/Autodesk/maya/scripts/
	(Replace USERNAME with your own)
2. Add the following line to your userSetup.py in the script directory to start Cosmos on Maya startup:
import cosmos

(If a "userSetup.py" doesn't exist, use the one from this folder, or create a new blank text-file with the above text)
If you already had Maya open, you would need to restart it, or run "import cosmos" in the script-editor.


##########  Usage ########## 
Next time you start Maya you should be able to activate cosmos with the shortcut:
Windows/Linux: CTRL + TAB
Mac: SHIFT + TAB

Ps. You can off course add Cosmos to whatever shortcut you want with the following code in the hotkey editor:
cosmos.start()

